"use client"

import OverviewSection from "../components/sections/OverviewSection"

export default function SyntheticV0PageForDeployment() {
  return <OverviewSection />
}